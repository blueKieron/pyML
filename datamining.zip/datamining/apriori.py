import numpy as np
from itertools import combinations  # 迭代工具

file=open('data/2.txt')
da=[]
for line in file.readlines():
    curLine=line.strip().split(" ")
    floatLine=list(map(float,curLine))
    da.append(floatLine[0:10])
minsp = 2
d = []
for i in range(len(da)):
    d.extend(da[i])
new_d = list(set(d))

def satisfy(s, s_new, k):  # 更新确实存在的L
    e = []
    ss_new = []
    for i in range(len(s_new)):
        for j in combinations(s_new[i], k):  # 迭代产生所有元素可能性组合
            e.append(list(j))
        if ([l for l in e if l not in s]) == []:
            ss_new.append(s_new[i])
        e = []
    return ss_new  # 筛选满足条件的结果


def count(s_new):  # 返回narray格式的C
    num = 0
    C = np.copy(s_new)
    C = np.column_stack((C, np.zeros(C.shape[0])))
    for i in range(len(s_new)):
        for j in range(len(da)):
            if ([l for l in s_new[i] if l not in da[j]]) == []:
                num = num + 1
        C[i, -1] = num
        num = 0
    return C


def limit(L):  # 删掉不满足阈值的C
    row = []
    for i in range(L.shape[0]):
        if L[i, -1] < minsp:
            row.append(i)
    L = np.delete(L, row, 0)
    return L


def generate(L, k):  # 实现由L至C的转换
    s = []
    for i in range(L.shape[0]):
        s.append(list(L[i, :-1]))
    s_new = []
    #    L = L.delete(L, -1, 1)
    #    l = L.shape[1]
    for i in range(L.shape[0] - 1):
        for j in range(i + 1, L.shape[0]):
            if (L[j, -2] > L[i, -2]):
                t = list(np.copy(s[i]))
                t.append(L[j, -2])
                s_new.append(t)  # s_new为列表
    s_new = satisfy(s, s_new, k)
    C = count(s_new)
    return C


# 初始的C与L
C = np.zeros([len(new_d), 2])
for i in range(len(new_d)):
    C[i:] = np.array([new_d[i], d.count(new_d[i])])
L = np.copy(C)
L = limit(L)
# 开始迭代
k = 1
while (np.max(L[:, -1]) > minsp):
    C = generate(L, k)  # 由L产生C
    L = limit(C)  # 由C产生L
    k = k + 1

# 对最终结果去重复
print((list(set([tuple(t) for t in L]))))