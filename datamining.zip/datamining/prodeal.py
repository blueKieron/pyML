import math

#数据读取
with open('data/1.txt','r') as f:
    nums=f.readlines()
#for nu in nums:
   # print(nu.rstrip())
num=len(nums)
box_depths=input('input:')
box_depth=float(box_depths)
print('源数据为：')
print("共 %d 箱 %d 个数据" %(math.ceil(num/box_depth),num))
#数据填补 程序通用
count=1
box=1
list_val=int(0)
if(isinstance(num/box_depth,float)):
    chazhi=int(math.ceil(num/box_depth)*box_depth-num)
    for i in range(chazhi):
        nums.append(70)
num_after=int(len(nums))
while(num_after!=0):
    if(count==1): print("箱%d:"  %box)
    if(count==int(box_depth)):
        print('%d' %int(nums[list_val]))
        box=box+1
        count=1
    else:
        print('%d'%int(nums[list_val]),end=' ')
        count=count+1
    list_val=list_val+1
    num_after=num_after-1

def mean():
    num_after1=int(len(nums))
    num_after2=0
    list_val1=0
    sum=0
    count1=1
    nlist=[]
    print('均值平滑后：')
    while(num_after1!=0):
        if(count1==box_depth):
            count1=1
            sum=sum+int(nums[list_val1])
            nlist.append(int(sum/box_depth))
            sum=0
        else:
            sum=sum+int(nums[list_val1])
            count1=count1+1
        list_val1 = list_val1+1
        num_after1 = num_after1 - 1
    for i in range(len(nlist)):
        print('\n箱%d' %(i+1))
        for j in range(int(box_depth)):
            print('%d ' %nlist[int(i)],end=' ')
    print('\n离群点值为：')
    while(num_after2<int(len(nums))):
        for i in range(len(nlist)):
            for j in range(int(box_depth)):
                if(abs(int(nums[num_after2])-nlist[i])>10):
                    print('箱%d' %(i+1))
                    print('%d' %int(nums[num_after2]))
                num_after2=num_after2+1



def medain():
    num_after1 = int(len(nums))
    list_val1 = 0
    sum = 0
    count1 = 1
    mid=0
    nlist = []
    print('\n中值平滑后：')
    while (num_after1 != 0):
        if (count1 == box_depth):
            count1 = 1
            nlist.append(int(sum))
        else:
            if(count1==int(box_depth/2) or count1==int(box_depth/2+1)):
                if(box_depth%2):
                    if(count1==box_depth/2+1):
                        sum=nums[list_val1]
                else:
                    if(count1==int(box_depth/2+1)):
                        sum=(int(nums[list_val1])+int(mid))/2
                    else:
                        mid=nums[list_val1]
            count1 = count1 + 1
        list_val1 = list_val1 + 1
        num_after1 = num_after1 - 1

    for i in range(len(nlist)):
        print('\n箱%d' % (i + 1))
        for j in range(int(box_depth)):
            print('%d ' % nlist[int(i)], end=' ')
def boundary():
    num_after1 = int(len(nums))
    list_val2 = 0
    count1 = 1
    num= 0
    nlist =list(range(100))
    print('\n边界值平滑后：')
    while (num_after1 != 0):
        if (count1 == box_depth):
            nlist[2*num+1]=nums[list_val2]
            count1 = 1
            num=num+1
        else:
            if(count1==1):
                nlist[2*num]=nums[list_val2]
            count1 = count1 + 1
        list_val2 = list_val2 + 1
        num_after1 = num_after1 - 1

    count2=1
    num2=0
    list_val3=0
    num_after2=int(len(nums))
    while (num_after2 != 0):
        if (count2 == 1):
            print('\n箱%d' %int(num2+1))
        if((int(nums[list_val3])-int(nlist[2*num2]))>(int(nlist[2*num2+1])-int(nums[list_val3]))):
            print('%d' %int(nlist[2*num2+1]),end=' ')
        else:
            print('%d' %int(nlist[2*num2]),end=' ')
        if(int(count2)==int(box_depth)):
            count2=0
            num2=num2+1
        count2 = count2 + 1
        list_val3 = list_val3 + 1
        num_after2 = num_after2 - 1
mean()
medain()
boundary()