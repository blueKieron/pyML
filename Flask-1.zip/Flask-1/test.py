
from flask import Flask
from flask.ext import restful

app = Flask(__name__)
api = restful.Api(app)

class HelloWorld(restful.Resource):
    def get(self):
        return {'hello': 'world'}

api.add_resource(HelloWorld, '/')

if __name__ == '__main__':
    app.run(debug=True)
    E = 20 + value[0] - value[1] + value[2] - value[3] + value[4] - value[5] + value[6] - value[7] + value[8] - value[9]
    N = 38 - value[10] + value[11] - value[12] + value[13] - value[14] - value[15] - value[16] - value[17] - value[18] - \
        value[19]
    A = 14 - value[20] + value[21] - value[22] + value[23] - value[24] + value[25] - value[26] + value[27] + value[28] + \
        value[29]
    C = 14 + value[30] - value[31] + value[32] - value[33] + value[34] - value[35] + value[36] - value[37] + value[38] + \
        value[39]
    O = 8 + value[40] - value[41] + value[42] - value[43] + value[44] - value[45] + value[46] + value[47] + value[48] + \
        value[49]
    sum = [[E, N, A, C, O]]
    sum = np.array(sum, dtype=np.float32)
    exe = fluid.Executor(fluid.CPUPlace())
    exe.run(fluid.default_main_program())
    param_path = "./paddle_model"
    [infer_program, feeded_var_name, target_var] = fluid.io.load_inference_model(executor=exe, dirname=param_path)
    result = exe.run(program=infer_program, feed={feeded_var_name[0]: sum}, fetch_list=target_var)
    lab = np.argmax(result[0][0])
    print(result, lab)
