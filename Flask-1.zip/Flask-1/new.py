# -*- coding: utf-8 -*
import numpy as np
import paddle.fluid as fluid
from flask import Flask,render_template,request,redirect, Response, send_file
app = Flask(__name__)

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == "GET":
        return render_template('login.html')
    else:
        user=request.form.get('user')
        pwd=request.form.get('pwd')
        if user=='alex' and pwd =='123':
            return render_template('success.html')
    return render_template('login.html',error='用户名或密码错误')

@app.route('/character',methods=['GET','POST'])
def character():
    pass
    if request.method == "GET":
        return render_template('character.html')
    else:
        result = request.form.to_dict()
        values= list(result.values())
        value = list(map(int, values))
        print(list(result.keys()))
        print(value)
        E = 20 + value[0] - value[1] + value[2] - value[3] + value[4] - value[5] + value[6] - value[7] + value[8] - value[9]
        N = 38 - value[10] + value[11] - value[12] + value[13] - value[14] - value[15] - value[16] - value[17] - value[18] - value[19]
        A = 14 - value[20] + value[21] - value[22] + value[23] - value[24] + value[25] - value[26] + value[27] + value[28] + value[29]
        C = 14 + value[30] - value[31] + value[32] - value[33] + value[34] - value[35] + value[36] - value[37] + value[38] + value[39]
        O = 8 + value[40] - value[41] + value[42] - value[43] + value[44] - value[45] + value[46] + value[47] + value[48] + value[49]
        sum = [[E, N, A, C, O]]
        mean_num=[20.113,19.029,28.443,23.472,29.086]
        print(sum)
        sum = np.array(sum, dtype=np.float32)
        exe = fluid.Executor(fluid.CPUPlace())
        exe.run(fluid.default_main_program())
        param_path = "./my_paddle_model"
        [infer_program, feeded_var_name, target_var] = fluid.io.load_inference_model(executor=exe, dirname=param_path)
        result = exe.run(program=infer_program, feed={feeded_var_name[0]: sum}, fetch_list=target_var)
        lab = np.argmax(result[0][0])
        if((sum[0][lab]-mean_num[lab])<0):
            temp=0
        else:
            temp=1
        choice=str(lab)+str(temp)
        l = {'00': '根据您的得分，主要属于低外向性。', '01': '根据您的得分，主要属于高外向性', '10': '根据您的得分，主要属于低神经质。', '11': '根据您的得分，主要属于高神经质',
             '20': '根据您的得分，主要属于低宜人性。', '21': '根据您的得分，主要属于高外向性', '30': '根据您的得分，主要属于低尽责性。', '31': '根据您的得分，主要属于高尽责性',
             '40': '根据您的得分，主要属于低开放性。', '41': '根据您的得分，主要属于高开放性', }
        lis = []
        lis.append({'choice':l[choice]})
        return render_template('test2.html', nums=lis)

@app.route('/model2', methods=['GET', 'POST'])
def l():
    if request.method == "GET":
        return render_template('model2.html')
    else:
        return render_template('model2.html')

@app.route('/3_replaced', methods=['GET', 'POST'])
def ll():
    if request.method == "GET":
        return render_template('3_replaced.html')
    else:
        return render_template('3_replaced.html')

@app.route('/templates/<dirname>/<filename>', methods=['GET'])
def file_request(dirname, filename):
    mime = None
    return send_file('templates/{0}/{1}'.format(dirname, filename), mimetype=None)

if __name__ == '__main__':
    app.run(debug=True)

