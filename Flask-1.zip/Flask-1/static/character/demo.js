﻿var $j = jQuery.noConflict();
//$j('.setnext').hide();
//$j('.setres').show();
var n_page = 10;
var CurrentSet = 1;
$j(document).on('click', '#nextbut', function () {

    var a = $j("input[Id*=qn]");
    for (var k = (CurrentSet - 1) * 5; k < CurrentSet * 5; k++) {
        if ($j(a)[k].value == "0") {
        //  alert("你还没回答第" + (k + 1) + "题，请全部做好再提交。");
          //  return false;
        }
    }

    CurrentSet++;
    $j('.set' + (CurrentSet - 1)).fadeOut(200, function () {
        $j('.set' + CurrentSet).fadeIn(200);
    });
    var progressValue = CurrentSet - 1;
    var sliderWidth = $j('.progress').width();
    var n_page_percent = 100/n_page;
    var tickPos = sliderWidth / n_page * progressValue - 25;
    $j('.progress-tick').animate({
        left: tickPos + 'px'
    }, {duration: 300, queue: false});
    $j('.progress-bar').animate({
        width: (progressValue * n_page_percent) + '%'
    }, {duration: 300, queue: false});
    $j('.progress-tick').html(Math.round(progressValue * n_page_percent));
    var formPos = $j('#test-form').offset();
    var formPos2 = formPos.top;
    $j('html, body').animate({scrollTop: formPos2 - 60}, 500);
    if (CurrentSet == n_page) {
        $j('.setnext').hide();
        $j('.setres').show();
    }
});


$j('.nav li:eq(0) a').addClass('navbar-li-selected');

$j(document).on('click', '#submbut', function () {

    var sliderWidth = $j('.progress').width();
    var tickPos = sliderWidth - 25;
    $j('.progress-tick').animate({
        left: tickPos + 'px'
    }, 300);
    $j('.progress-bar').animate({
        width: '100%'
    }, 300);
    $j('.progress-tick').html('100');
    $j("#submbut").attr('disabled', 'disabled');
    $j('#test-form').submit();
});

function setAnswer(index, newval) {
    $j('#qn' + index).val(newval);
}

$j(document).on('click', '.decision .caption.left', function () {
    $j(this).next().children('.option').removeClass('active');
    $j(this).next().children('.option.agree.max').addClass('active');
});

$j(document).on('click', '.decision .caption.right', function () {
    $j(this).prev().children('.option').removeClass('active');
    $j(this).prev().children('.option.disagree.max').addClass('active');
});

function form_check(form) {
    debugger;
    var a = $j("input[Id*=qn]");
    for (var k = 0; k < $j(a).length; k++) {
        if ($j(a)[k].value == "0") {
       //     alert("你还没回答第" + (k + 1) + "题，请全部做好再提交。");
         //   return false;
        }
    }
}