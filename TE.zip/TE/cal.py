# encoding: utf-8
# Define GPIO to LCD mapping
import time
import RPi.GPIO as GPIO

LCD_RS = 7
LCD_E = 8
LCD_D4 = 4
LCD_D5 = 24
LCD_D6 = 23
LCD_D7 = 27
btnG, btnR = 5, 18

R = 22

# Define some device constants
LCD_WIDTH = 16  # Maximum characters per line
LCD_CHR = True
LCD_CMD = False
LCD_LINE_1 = 0x80  # LCD RAM address for the 1st line
LCD_LINE_2 = 0xC0  # LCD RAM address for the 2nd line
# Timing constants
E_PULSE = 0.0005
E_DELAY = 0.0005


class keypad(object):
    KEYPAD = [
        ['+', '1', '2', '3'],
        ['-', '4', '5', '6'],
        ['*', '7', '8', '9'],
        ['/', 'C', '0', '=']]
    ROW = [21, 17, 20, 26]
    COLUMN = [6, 25, 19, 16]


def __init__():
    GPIO.cleanup()
    GPIO.setmode(GPIO.BCM)


def getkey():
    GPIO.setmode(GPIO.BCM)
    for i in range(len(keypad.COLUMN)):
        GPIO.setup(keypad.COLUMN[i], GPIO.OUT)
        GPIO.output(keypad.COLUMN[i], GPIO.LOW)
    for j in range(len(keypad.ROW)):
        GPIO.setup(keypad.ROW[j], GPIO.IN, pull_up_down=GPIO.PUD_UP)
    RowVal = -1
    for i in range(len(keypad.ROW)):
        RowStatus = GPIO.input(keypad.ROW[i])
        if RowStatus == GPIO.LOW:
            RowVal = i
    if RowVal < 0 or RowVal > 3:
        exit()
        return
    GPIO.setup(keypad.ROW[RowVal], GPIO.OUT)
    GPIO.output(keypad.ROW[RowVal], GPIO.HIGH)
    for j in range(len(keypad.COLUMN)):
        GPIO.setup(keypad.COLUMN[j], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    ColumnVal = -1
    for i in range(len(keypad.COLUMN)):
        ColumnStatus = GPIO.input(keypad.COLUMN[i])
        if ColumnStatus == GPIO.HIGH:
            ColumnVal = i
            while GPIO.input(keypad.COLUMN[i]) == GPIO.HIGH:
                time.sleep(0.05)
    if ColumnVal < 0 or ColumnVal > 3:
        exit()
        return
    exit()
    return keypad.KEYPAD[RowVal][ColumnVal]

def exit():
    import RPi.GPIO as GPIO
    for i in range(len(keypad.ROW)):
        GPIO.setup(keypad.ROW[i], GPIO.IN, pull_up_down=GPIO.PUD_UP)
    for j in range(len(keypad.COLUMN)):
        GPIO.setup(keypad.COLUMN[j], GPIO.IN, pull_up_down=GPIO.PUD_UP)

import re

def multdiv(l, x):
    a = l.index(x)
    if x == '*':
        k = float(l[a - 1]) * float(l[a + 1])
        del l[a - 1], l[a - 1], l[a - 1]
    else:
        if int(l[a + 1]) == 0:
            lcd_string('ZeroExpection', LCD_LINE_2)
        else:
            k = float(l[a - 1]) / float(l[a + 1])
            del l[a - 1], l[a - 1], l[a - 1]
    l.insert(a - 1, str(k))
    return l


def fun(l):
    sum = 0
    while 1:
        if '*' in l and '/' not in l:
            multdiv(l, '*')
        elif '*' not in l and '/' in l:
            multdiv(l, '/')
        elif '*' in l and '/' in l:
            a = l.index('*')
            b = l.index('/')
            if a < b:
                multdiv(l, '*')
            else:
                multdiv(l, '/')
        else:
            if l[0] == '-':
                l[0] = l[0] + l[1]
                del l[1]
            sum += float(l[0])
            for i in range(1, len(l), 2):
                if l[i] == '+':
                    sum += float(l[i + 1])
                else:
                    sum -= float(l[i + 1])
            break
    return sum


def calculate(expression):
    l = re.findall('([\d\.]+|/|-|\+|\*)', expression)
    a = fun(l)
    print
    a
    return str(a)


def main():
    # Main program block
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)  # Use BCM GPIO numbers
    GPIO.setup(LCD_E, GPIO.OUT)  # E
    GPIO.setup(LCD_RS, GPIO.OUT)  # RS
    GPIO.setup(LCD_D4, GPIO.OUT)  # DB4
    GPIO.setup(LCD_D5, GPIO.OUT)  # DB5
    GPIO.setup(LCD_D6, GPIO.OUT)  # DB6
    GPIO.setup(LCD_D7, GPIO.OUT)  # DB7
    GPIO.setup(btnG, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(btnR, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(R, GPIO.OUT)
    # Initialise display
    lcd_init()
    key = None
    str1 = ''
    str2 = ''
    str = ''
    while True:
        key = getkey()
        if key != None:
            GPIO.output(R, False)
            str1 = str1 + key
            lcd_string(str1, LCD_LINE_1)
        if key == '=':
            str2 = calculate(str1)
            if len(str2) > 8:
                lcd_string('numeric overflow', LCD_LINE_2)
            else:
                lcd_string(str2, LCD_LINE_2)
        else:
            GPIO.output(R, True)


def lcd_init():
    # Initialise display
    lcd_byte(0x33, LCD_CMD)  # 110011 Initialise
    lcd_byte(0x32, LCD_CMD)  # 110010 Initialise
    lcd_byte(0x06, LCD_CMD)  # 000110 Cursor move direction
    lcd_byte(0x0C, LCD_CMD)  # 001100 Display On,Cursor Off, Blink Off
    lcd_byte(0x28, LCD_CMD)  # 101000 Data length, number of lines, font size
    lcd_byte(0x01, LCD_CMD)  # 000001 Clear display
    time.sleep(E_DELAY)


def lcd_byte(bits, mode):
    GPIO.output(LCD_RS, mode)  # RS
    # High bits
    GPIO.output(LCD_D4, False)
    GPIO.output(LCD_D5, False)
    GPIO.output(LCD_D6, False)
    GPIO.output(LCD_D7, False)
    if bits & 0x10 == 0x10:
        GPIO.output(LCD_D4, True)
    if bits & 0x20 == 0x20:
        GPIO.output(LCD_D5, True)
    if bits & 0x40 == 0x40:
        GPIO.output(LCD_D6, True)
    if bits & 0x80 == 0x80:
        GPIO.output(LCD_D7, True)

    # Toggle 'Enable' pin
    lcd_toggle_enable()

    # Low bits
    GPIO.output(LCD_D4, False)
    GPIO.output(LCD_D5, False)
    GPIO.output(LCD_D6, False)
    GPIO.output(LCD_D7, False)
    if bits & 0x01 == 0x01:
        GPIO.output(LCD_D4, True)
    if bits & 0x02 == 0x02:
        GPIO.output(LCD_D5, True)
    if bits & 0x04 == 0x04:
        GPIO.output(LCD_D6, True)
    if bits & 0x08 == 0x08:
        GPIO.output(LCD_D7, True)

    # Toggle 'Enable' pin
    lcd_toggle_enable()


def lcd_toggle_enable():
    # Toggle enable
    time.sleep(E_DELAY)
    GPIO.output(LCD_E, True)
    time.sleep(E_PULSE)
    GPIO.output(LCD_E, False)
    time.sleep(E_DELAY)


def lcd_string(message, line):
    # Send string to display

    message = message.ljust(LCD_WIDTH, " ")

    lcd_byte(line, LCD_CMD)

    for i in range(LCD_WIDTH):
        lcd_byte(ord(message[i]), LCD_CHR)


if __name__ == '__main__':
    main()
